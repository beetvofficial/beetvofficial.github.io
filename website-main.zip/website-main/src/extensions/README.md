---
title: Extensions
description: List of available extensions to use with Tachiyomi, you can download them from here or from the app.
lang: en-US
---

# Extensions

List of available extensions to use with Tachiyomi, you can download them from here or from the app.

<ExtensionsWrapper/>
