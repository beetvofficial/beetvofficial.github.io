module.exports = [
	{ text: "Home", link: "/" },
	{ text: "Help Center", link: "/help/" },
	{ text: "Download", link: "/download/" },
	{ text: "Extensions", link: "/extensions/" },
];
